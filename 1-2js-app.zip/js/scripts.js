let pokemonList = [
    { name: "Pikachu", types: ["electric"], height: 45 },
    { name: "Mewtwo", types: ["psychic"], height: 165 },
    { name: "Kicklee", types: ["fighting"], height: 140 },
];
