alert('Hello world');
let favoriteFood = 'tuna'
document.write(favoriteFood)